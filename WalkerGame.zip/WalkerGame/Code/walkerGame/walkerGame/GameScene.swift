//
//  GameScene.swift
//  walkerGame
//
//  Created by Samuel Hoffmann on 7/5/17.
//  Copyright © 2017 Samuel Hoffmann. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    
    var frames : [Frame] = []
    
    var movePos = SKAction()
    var moveNeg = SKAction()
    var delay = SKAction()
    var moveFoward = SKAction()
    var moveBackward = SKAction()
    var movingDirection = 0
    
    var posDistance = 0
    var negDistance = 0
    var displacement = 0
    
    var leftHomeScreen = false
    
    var cat = SKSpriteNode()
    var cat2 = SKSpriteNode()
    
    var catPos = 0
    
    
    
    override func didMove(to view: SKView) {
        
        
        let HouseFrame = Frame(special: 1)
        HouseFrame.position = CGPoint(x: 0, y: -27)
        frames.append(HouseFrame)
        self.addChild(HouseFrame)
        
        
        movePos = SKAction.run({
            () in
            print(self.posDistance)
            self.moveFrames(pos: CGPoint(x: 1, y: 1))
            
        })
        
        moveNeg = SKAction.run({
            () in
            
            self.moveFrames(pos: CGPoint(x: -1, y: -1))
            
        })
        
        delay = SKAction.wait(forDuration: 0.2)
        
        moveFoward = SKAction.sequence([movePos, delay])
        
        moveBackward = SKAction.sequence([moveNeg, delay])
        
        
        
        cat = SKSpriteNode(imageNamed: "cat")
        cat.position.y = -70
        cat.zPosition = 10
        
        self.addChild(cat)
        
        
        cat2 = SKSpriteNode(imageNamed: "cat2")
        cat2.position.y = -70
        cat2.zPosition = 10
        cat2.alpha = 0
        self.addChild(cat2)
        
        
    }
    
    
    
    func moveFrames(pos: CGPoint){
        if pos.x > 0 {
            
            cat.alpha = 1
            cat2.alpha = 0
            
            print("right")
            
            posDistance += 1
            displacement += 1
            
            if cat.position.x <= 0{
                
                catPos = catPos + 51
                
                cat.run(SKAction.moveBy(x: 51, y: 0, duration: 0.2))
                
                cat2.run(SKAction.moveBy(x: 51, y: 0, duration: 0.2))
                
                
            }else{
            
            
                for bob in frames {
                    
                    bob.run(SKAction.moveBy(x: -51, y: 0, duration: 0.2))
                }
            
                var move = true
            
            
                if move == true {
                
                    let tf1 = Frame()
                    tf1.position = CGPoint(x: self.frame.width/2 + 51, y: 0)
                    
                    frames.append(tf1)
                    self.addChild(tf1)
                
                }
            }
        
        }else{
            
            //flip cat
            
            cat.alpha = 0
            cat2.alpha = 1
            
            //move backwards
            catPos = catPos - 51
            
            cat.run(SKAction.moveBy(x: -51, y: 0, duration: 0.2))
            
            cat2.run(SKAction.moveBy(x: -51, y: 0, duration: 0.2))
            
        }
        
        
        for bob in frames {
            
            if bob.position.x < -self.frame.width/2 - 51 {
                frames.removeFirst()
                bob.removeFromParent()
            }
            
            if bob.position.x > self.frame.width/2 + 51 {
                frames.removeLast()
                bob.removeFromParent()
            }
            
            
        }
        
        
    }
    
    
    func appendToFront(frame: Frame){
        
        print(frames.count)
        
        frames.append(Frame())
        
        print(frames.count)
        
        for mary in 1...frames.count-1 {
            
            print("swapping \(frames.count - mary + 1) with \(frames.count - mary)")
            
            frames[frames.count - mary] = frames[frames.count - mary - 1]
            
        }
        
        frames[0] = frame
        
    }
    
    
    
    
    
    
    func touchDown(atPoint pos : CGPoint) {
        
        if pos.x > 0 {
            
            movingDirection = 1
            self.run(SKAction.repeatForever(moveFoward))
            
        }else{
            
            movingDirection = -1
            self.run(SKAction.repeatForever(moveBackward))
            
        }
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
        if pos.x > 0 {
            
            if movingDirection == -1 {
                self.removeAllActions()
                self.run(SKAction.repeatForever(moveFoward))
                movingDirection = 1
            }
            
        }else{
            
            if movingDirection == 1 {
                self.removeAllActions()
                self.run(SKAction.repeatForever(moveBackward))
                movingDirection = -1
            }
            
        }
        
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
        self.removeAllActions()
        movingDirection = 0
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchMoved(toPoint: t.location(in: self)) }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
