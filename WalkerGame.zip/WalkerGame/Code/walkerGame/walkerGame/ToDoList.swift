//
//  ToDoList.swift
//  walkerGame
//
//  Created by Samuel Hoffmann on 7/11/17.
//  Copyright © 2017 Samuel Hoffmann. All rights reserved.
//

import Foundation


/**
 

 1: work on artwork
 2: work on home screen
 3: work on movement machanics
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 */


