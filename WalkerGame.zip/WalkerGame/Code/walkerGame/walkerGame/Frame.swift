//
//  Frame.swift
//  walkerGame
//
//  Created by Samuel Hoffmann on 7/5/17.
//  Copyright © 2017 Samuel Hoffmann. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit
import GameplayKit

class Frame: SKNode {
    
    var sky = SKSpriteNode()
    var hills = SKSpriteNode()
    var floor = SKSpriteNode()
    
    var house = SKSpriteNode()
    
    
    override init() {
        super.init()
        
        makeFrame(special: 0)
        
    }
    
    init(special: Int) {
        super.init()
        
        makeFrame(special: special)
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func makeFrame(special: Int){
        
        
        
        if(special == 1) {
            
            
            house = SKSpriteNode(imageNamed: "house")
            house.zPosition = 1
            
            self.addChild(house)
            
            
        }else{
            
            sky = SKSpriteNode(imageNamed: "sky")
            
            sky.zPosition = 0
            
            
            self.addChild(sky)
            
            
            
            let random = arc4random_uniform(20)
            let random2 = arc4random_uniform(11) + 1
            
            hills = SKSpriteNode(imageNamed: "hills")
            
            hills.zPosition = CGFloat(random2)
            
            if random == 0 {
                self.addChild(hills)
            }else{
                
            }
            
            
            
            
            floor = SKSpriteNode(imageNamed: "floor")
            
            floor.zPosition = 0
            
            self.addChild(floor)
            
            
            
        }
        
        
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
}

