//
//  BetterArray.swift
//  walkerGame
//
//  Created by Samuel Hoffmann on 7/11/17.
//  Copyright © 2017 Samuel Hoffmann. All rights reserved.
//

import Foundation
